package q3;
//Box 클래스는 높이, 너비, 깊이를 가지며, volume 함수를 통해 부피를 구할 수 있습니다
//Box 클래스의 생성자, volume 메소드를 구현해야합니다.
class Box {
    private int width;
    private int height;
    private int depth;
    int volume() {
    	return width*height*depth;
    }
    public Box() {
    	width = 1;
    	height=1;		
    	depth=1;
    }
	public Box(int width, int height, int depth) {
		this.width=width;
		this.height=height;
		this.depth=depth;
	}
    
}