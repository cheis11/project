package q3;

public class BoxTest {

	public static void main(String[] args) {
		Box box1 = new Box();
		Box box2 = new Box(2, 2, 2);
		
		System.out.println(box1.volume());
		System.out.println(box2.volume());

	}

}

